﻿using CadastroFornecedor.Models;
using System.Runtime.ConstrainedExecution;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace CadastroFornecedor.Data
{
    public class AppDBInitializer
    {
        public static void Seed(IApplicationBuilder applicationBuilder)
        {
            using (var serviceScope = applicationBuilder.ApplicationServices.CreateScope())
            {
                var context = serviceScope.ServiceProvider.GetService<AppCont>();
                context.Database.EnsureCreated();

                if (!context.Cadastros.Any())
                {
                    context.Cadastros.AddRange(new List<Cadastro>()
                    {
                        new Cadastro()
                        {
                            RazaoSocial = "ABC Comércio Ltda.",
                            Fantasia = "MegaStore Eletrônicos",
                            Email = "contato@megastore.com",
                            Telefone = "(11) 5555-5555",
                            Logradouro = "Avenida das Inovações",
                            Numero = "1234",
                            Bairro = "Centro",
                            Cidade = "Cidade Fictícia",
                            Uf = "SP",
                            Cep = "12345-678",
                            NomeContato = "João da Silva"
                        },
                        new Cadastro()
                        {
                            RazaoSocial = "XYZ Comércio de Alimentos",
                            Fantasia = "Supermercado da Esquina",
                            Email = "contato@superesquina.com",
                            Telefone = "(21) 9876-5432",
                            Logradouro = "Rua das Flores",
                            Numero = "567",
                            Bairro = "Vila Verde",
                            Cidade = "Cidade Imaginária",
                            Uf = "RJ",
                            Cep = "54321-987",
                            NomeContato = "Maria Oliveira"
                        }
                    });
                    context.SaveChanges();
                }
            }
        }
    }
}
