﻿using System.ComponentModel.DataAnnotations;

namespace CadastroFornecedor.Models
{
    public class Cadastro
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string RazaoSocial { get; set; }

        [Required]
        public string Fantasia { get; set; }

        [Required]
        public string Email { get; set;}

        [Required]
        public string Telefone { get; set;}

        [Required]
        public string Logradouro { get; set; }

        [Required]
        public string Numero { get; set;}

        [Required]
        public string Bairro { get; set;}

        [Required]
        public string Cidade { get; set;}

        [Required]
        public string Uf { get; set;}

        [Required]
        public string Cep { get; set;}

        [Required]
        public string NomeContato { get; set;}

    }
}
