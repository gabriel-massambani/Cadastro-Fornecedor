﻿using CadastroFornecedor.Data;
using CadastroFornecedor.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CadastroFornecedor.Controllers
{
    public class CadastrosController : Controller
    {
        private readonly AppCont _appCont;

        public CadastrosController(AppCont appCont)
        {
            _appCont = appCont;
        }

        public IActionResult Index()
        {
            var allTask = _appCont.Cadastros.ToList();
            return View(allTask);
        }

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var cadastro = await _appCont.Cadastros
                .FirstOrDefaultAsync(m => m.Id == id);
            if (cadastro == null)
            {
                return NotFound();
            }

            return View(cadastro);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]

        public async Task<IActionResult> Create(Cadastro cadastro)
        {
            if (ModelState.IsValid)
            {
                _appCont.Add(cadastro);
                await _appCont.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View(cadastro);
        }

        [HttpGet]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var cadastro = await _appCont.Cadastros.FindAsync(id);
            if (cadastro == null)
            {
                return BadRequest();
            }
            return View(cadastro);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]

        public async Task<IActionResult> Edit(
            int? id,
            Cadastro cadastro)
        {
            if (id == null)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                _appCont.Update(cadastro);
                await _appCont.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(cadastro);
        }

        [HttpGet]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var cadastro = await _appCont.Cadastros
                .FirstOrDefaultAsync(x => x.Id == id);

            if (cadastro == null)
            {
                return NotFound();
            }
            return View(cadastro);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]

        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var cadastro = await _appCont.Cadastros.FindAsync(id);
            _appCont.Cadastros.Remove(cadastro);
            await _appCont.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }

}

